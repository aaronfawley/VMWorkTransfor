import numpy as np
import os
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.patches as mpatches
import matplotlib.backends.backend_pdf
pdf = matplotlib.backends.backend_pdf.PdfPages('output.pdf')
    #the plots need to rely on something other than
#    CS params because they are not calculated properly for 1 particle bro
def write_FODO(filename):
    with open(filename,'w') as f:
        f.write('''
call file = RCS_Lattice.lat;

ke     : =16.0 ;
etotal :=pmass+ke ;

beam, particle=proton, energy=etotal ;


beta=sqrt(1-1/beam->gamma^2); ! <== just a very heavy-handed way of getting beta == p/E
etax  :=beta*table(twiss,dx); 
detax :=beta*table(twiss,dpx) ;

USE, PERIOD=SCELL;
Twiss;
	
!*******fit to design tune - can also fit to individual cell********

Use, period=SCELL;
match, sequence=SCELL;
vary, name=qfk1,step=1e-8;
vary, name=qdk1,step=1e-8;
constraint, range=#e, mux=(100/360), muy=(100/360);
MIGRAD, calls=1000, tolerance = 1.e-11 ;
endmatch;

USE, PERIOD=SCELL;
Twiss, file=twisscell.out ;

Use, period=RCS ;
Twiss, file=twiss.out ;


USE, PERIOD=SCELL;
 ! select, flag =twiss, column=name,s,betx,alfx,mux,etax,detax,bety,alfy,muy;
Twiss,file=twisscell.out;
plot, HAXIS=s,interpolate,
        VAXIS1=betx,bety,
		VAXIS2=etax,
		HMAX=(531/CellNum),
		STYLE=1,
		COLOUR=100,
        TITLE="BOOSTER PROPOSAL";


Use, period=RCS ;
!select, flag =twiss, column=name,s,betx,alfx,mux,etax,detax,bety,alfy,muy;
Twiss, file=twiss.out;
 plot, HAXIS=s, 
        VAXIS1=betx,bety,
		VAXIS2=etax,
		HMAX=531.,
		STYLE=1,
		COLOUR=100,
        TITLE="BOOSTER PROPOSAL";

sigmax: = 0.00286 ;
sigmay: = 0.02776 ;

  BETAX  = table(twiss,RCS$START,BETX );
  ALPHAX  = table(twiss,RCS$START,ALFX );
  BETAY = table(twiss,RCS$START,BETY);
  ALPHAY  = table(twiss,RCS$START,ALFY);

Create, table=outerdist, column=xs,pxs,ys,pys;

nprotons : =6 ;

n: = 1 ;
ptc_create_universe;
ptc_create_layout;
while(n <= nprotons ) {
   radiusx   = sigmax * n ;
   anglex    = twopi/nprotons * (n-1) ;
   xs      : = radiusx * cos(anglex) ;
   pxs     : = radiusx * sin(anglex) ;
   radiusy   = sigmay * n ; 
   angley    = twopi/nprotons * (n-1) ;
   ys      : = radiusy * cos(angley) ;
   pys     : = radiusy * sin(angley) ;
ptc_start, x=xs, px=pxs, y=0, py=0;
Fill, table=outerdist, row=n ;
n  = n+1 ;
} ;
Write, table=outerdist, file= outerdist.tfs ;


ptc_track,ICASE=5,dump,onetable,turns=200, maxaper={1, 1, 1, 1, 100000, 1},ffile=10,ELEMENT_BY_eLEMENT=false;
ptc_track_end;
ptc_end;
!=== End Particle Tracking Section ===!
stop;





















ke     : =16.0 ;
etotal :=pmass+ke ;

beam, particle=proton, energy=etotal ;
call file=RCS_lattice.lat  ;
USE, PERIOD=RCS;
!SELECT, FLAG=MAKETHIN, CLASS=sbend, SLICE=4, THICK=false;
!SELECT, FLAG=MAKETHIN, CLASS=quadrupole, SLICE=4, THICK=false;
!MAKETHIN, SEQUENCE=RCS, style=teapot;


beta=sqrt(1-1/beam->gamma^2); ! <== just a very heavy-handed way of getting beta == p/E
etax  :=beta*table(twiss,dx); 
detax :=beta*table(twiss,dpx) ;

USE, PERIOD=SCELL;
Twiss;
	
!*******fit to design tune - can also fit to individual cell********

Use, period=SCELL;
match, sequence=SCELL;
vary, name=qfk1,step=1e-8;
vary, name=qdk1,step=1e-8;
constraint, range=#e, mux=(100/360), muy=(100/360);
LMDIF, calls=1000, tolerance = 1.e-11 ;
endmatch;

USE, PERIOD=SCELL;
!select, flag=twiss, clear;
  !select, flag =twiss, column=name,s,betx,alfx,mux,etax,detax,bety,alfy,muy;
Twiss,file=twisscell.out;
plot, HAXIS=s,
        VAXIS1=betx,bety,
		VAXIS2=etax,
		HMAX=(531/CellNum),
		STYLE=1,
		COLOUR=100,
        TITLE="BOOSTER PROPOSAL";


Use, period=RCS ;
!select, flag =twiss, column=name,s,betx,alfx,mux,etax,detax,bety,alfy,muy;
Twiss, file=twiss.out;
 plot, HAXIS=s, 
        VAXIS1=betx,bety,
		VAXIS2=etax,
		HMAX=531.,
		STYLE=1,
		COLOUR=100,
        TITLE="BOOSTER PROPOSAL";

sigmax: = 0.00286 ;
sigmay: = 0.02776 ;

  BETAX  = table(twiss,RCS$START,BETX );
  ALPHAX  = table(twiss,RCS$START,ALFX );
  BETAY = table(twiss,RCS$START,BETY);
  ALPHAY  = table(twiss,RCS$START,ALFY);
!  CENTER of DISTRIBUTION
!   xs      : = 0 ;
!   pxs     : = 0 ;
!   ys      : = 0 ;
!   pys     : = 0 ;
!   zs      : = 0 ;
!   pzs     : = 0 ;

Create, table=outerdist, column=xs,pxs,ys,pys;

!Fill, table=Gaussdist.tfs, row=1 ;

!  Fill table with either a Gaussian or outer 99% ellipse with 10 equal spaced points
nprotons : =10 ;

n: = 1 ;

while(n <= nprotons ) {
!   radiusx   = sigmax * gauss() ;
   radiusx   = sigmax * 3 ;
!   anglex    = twopi * ranf() ;
   anglex    = twopi/nprotons * (n-1) ;
   xs      : = radiusx * cos(anglex) ;
   pxs     : = radiusx * sin(anglex) ;
   pxs       = (pxs - alphax*xs)/betax ;
!   radiusy   = sigmay * gauss() ;
   radiusy   = sigmay * 3 ;
!   angley    = twopi * ranf() ;
   angley    = twopi/10 * (n-1) ;
   ys      : = radiusy * cos(angley) ;
   pys     : = radiusy * sin(angley) ;
   pys        = (pys - alphay*ys)/betay ;

Fill, table=outerdist, row=n ;
n  = n+1 ;
} ;
Write, table=outerdist, file= outerdist.tfs ;





!=== Begin Particle Tracking Section ===

use,period=RCS;
ptc_create_universe;
ptc_create_layout;
i=0;
elli_tracking(xx,yy,zz): macro = {myval = table(xx,yy,zz);};
while (i<10){
value,i;
XB=table(outerdist.tfs,XS,i);
PXB=table(outerdist,PXS,i) ;
YB=table(outerdist,YS,i) ;
PYB=table(outerdist,PYS,i) ;
ptc_start, x=XB,
           px=PXB,
		   y=YB,
		   PY=PYB;
i=i+1;
}
ptc_observe,place=MID;
ptc_track,turns=100,ICASE=5,element_by_element=true,file=EllipseTrack,dump,onetable,maxaper = {0.5, 1,1,1,100000,1};
ptc_track_end;
ptc_end;
!=== End Particle Tracking Section ===
stop;

!<PTC_CODE>
stop ;

''')


def run_MAD(filename):
    os.system(r'madx < {} > out.txt'.format(filename))

def parsetwiss(filename):
    names = []
    keywords = []
    s = []
    betx = []
    bety = []
    alfx = []
    alfy = []
    mux = []
    muy = []
    dx = []
    dy = []
    L = []

    with open(filename,'r') as f:
        lines = f.readlines()
        headers = lines[46].split()
        del headers[0]
        for line in lines[48:]:
            names.append(line.split()[headers.index('NAME')].strip('\"'))
            keywords.append(line.split()[headers.index('KEYWORD')].strip('\"'))
            s.append(float(line.split()[headers.index('S')]))
            betx.append(float(line.split()[headers.index('BETX')]))
            alfx.append(float(line.split()[headers.index('ALFX')]))
            bety.append(float(line.split()[headers.index('BETY')]))
            alfy.append(float(line.split()[headers.index('ALFY')]))
            mux.append(float(line.split()[headers.index('MUX')]))
            muy.append(float(line.split()[headers.index('MUY')]))
            dx.append(float(line.split()[headers.index('DX')]))
            dy.append(float(line.split()[headers.index('DY')]))
            L.append(float(line.split()[headers.index('L')]))
    return names,keywords,s,betx,bety,alfx,alfy,mux,muy,dx,dy,L
    
def plot_twiss(names,keywords,s,betx,bety,dx,dy):   

    box_height = 0.25
    def draw_quad(s_start,length,name,color):
        plt.gca().add_patch(mpatches.Rectangle((s_start, -0.5*box_height), length, box_height, facecolor=color,zorder=10))
        plt.text(s_start+length/2,-1.5*box_height,name,horizontalalignment='center',fontsize=12,rotation='horizontal',color=color)
    def draw_dipole(s_start,length,name,color):
        plt.gca().add_patch(mpatches.Rectangle((s_start, -0.5*box_height), length, box_height, facecolor=color,zorder=10))
        plt.text(s_start+length/2,-1.5*box_height,name,horizontalalignment='center',fontsize=12,rotation='horizontal',color=color)
    def plotMarker(name,height):
        s_val=s[names.index(name)]
        plt.axvline(x=s_val,color='red',linestyle='--')
        plt.text(s_val+0.1,height,name,color='red',rotation=90)

    plt.figure(figsize=(16,8))
    plt.suptitle('FODO example',fontsize=22)

    plt.subplot(311)
    plt.plot(s,[0]*len(s),'k-')
    plt.xlim(0,s[-1])
    plt.ylim(-1,1)
    plt.gca().set_xlim(left=0)
    plt.gca().get_xaxis().set_ticks([])
    plt.gca().get_yaxis().set_ticks([])
    plt.gca().set_facecolor('#f1f1f1')
    # Plot quads and dipoles
    for i in range(len(keywords)):
        if 'QUADRUPOLE' in keywords[i]:
            draw_quad(s[i]-L[i],L[i], names[i], '#CB6015')
        elif 'RBEND' in keywords[i]:
            draw_dipole(s[i]-L[i],L[i], names[i], '#004C97')
        elif 'OBS' in names[i]:
            plotMarker(names[i], 0.6)

    plt.subplot(312)
    plt.plot(s,betx,label=r'$\beta_x$')
    plt.plot(s,bety,label=r'$\beta_y$')
    plt.xlabel('s [m]')
    plt.xlim(0,s[-1])
    plt.ylabel(r'$\beta$ [m]',fontsize=14)
    #plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.15),
    #      ncol=3, fancybox=True, shadow=True)
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    plt.gca().set_facecolor("#F8F8F8")
    plt.grid()
    
    plt.subplot(313)
    plt.plot(s,dx,'b',label=r'$D_x [m]$')
    plt.plot(s,dy,'g',label=r'$D_y [m]$')
    plt.xlabel('s [m]')
    plt.xlim(0,s[-1])
    plt.ylabel(r'$D [m]$',fontsize=14)
    #plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.15),
    #      ncol=3, fancybox=True, shadow=True)
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    plt.gca().set_facecolor("#F8F8F8")
    plt.grid()
    
    #plt.tight_layout()
    plt.subplots_adjust(top=0.92)
            
        
def makeParticles(alpha,beta,e,nparticles):
    gamma = (1+alpha**2)/beta
    sigmax = (e*beta)**0.5
    sigmaxp = (e*gamma)**0.5
    m = 0.5*np.arctan((2*alpha)/(gamma - beta))
    x = np.random.normal(0,sigmax,nparticles)
    xp = m*x + np.random.normal(0,sigmaxp,nparticles)
    
    return x,xp
    
def parse_tracking_output(filename,nparticles,n_turns):
    # Don't forget to pass number of obs points
    x_new = [[] for i in range(n_turns)]
    y_new = [[] for i in range(n_turns)]
    px_new = [[] for i in range(n_turns)]
    py_new = [[] for i in range(n_turns)]
    
    with open(filename,'r') as f:
        lines = f.readlines()

    n = 0
    for i in range(0,len(lines[8:]),1):
        if '#segment' in lines[i]:
            for j in range(i+1,i+nparticles+1,1):
                try:
                    x_new[n].append(float(lines[j].split()[2]))
                    px_new[n].append(float(lines[j].split()[3]))
                    y_new[n].append(float(lines[j].split()[4]))
                    py_new[n].append(float(lines[j].split()[5]))
                except:
                    pass
            n=n+1
    return x_new, px_new, y_new, py_new

def get_CS_params(x,xp):
    x = np.asarray(x)
    xp = np.asarray(xp)
    
    s11 = np.mean(x**2)
    s12 = np.mean(x*xp)
    s22 = np.mean(xp**2)
    
    epsilon = (s11*s22 - s12**2)**0.5
    beta = s11/epsilon
    alpha = -s12/epsilon
    gamma = (1+alpha**2)/beta
    
    return alpha, beta, gamma, epsilon
    
def draw_ellipse(alpha,beta,gamma,epsilon):
    # Plots the RMS (one-sigma) ellipse
    x_ellipse = np.linspace(-(epsilon*beta)**0.5,(epsilon*beta)**0.5,100)
    xp_pos = (1/beta)*(-alpha*x_ellipse + (alpha**2*x_ellipse**2+beta*epsilon-beta*gamma*x_ellipse**2)**0.5)
    xp_neg = (1/beta)*(-alpha*x_ellipse - (alpha**2*x_ellipse**2+beta*epsilon-beta*gamma*x_ellipse**2)**0.5)
    plt.plot(x_ellipse,xp_pos,'r',linewidth=0.5)
    plt.plot(x_ellipse,xp_neg,'r',linewidth=0.5)

def PSplot(x,xp,y,yp,title):
    # Ensure numpy arrays
    x = np.asarray(x)
    xp = np.asarray(xp)
    y = np.asarray(y)
    yp = np.asarray(yp)
    
    plt.figure(figsize=(12,6))
    markersize=0.75
    
    plt.suptitle(title)

    alphax, betax, gammax, epsilonx = get_CS_params(x,xp)
    xtextstr = r'$\beta_x = %.2f m$'%(betax)+'\n'+r'$\alpha_x = %.2f$'%(alphax)+'\n'+r'$\epsilon_x (RMS) = %.2f$'%(epsilonx*1E6)+r' $\pi*mm*mr$'
    plt.subplot(121)
    plt.title('Horizontal')
    plt.plot(x,xp,'o',markersize=markersize)
    plt.xlabel('x [m]')
    plt.ylabel('x\' [r]')
    plt.xlim(-3.0*(epsilonx*betax)**0.5, 3.0*(epsilonx*betax)**0.5)
    plt.ylim(-3.0*(epsilonx*betax)**0.5, 3.0*(epsilonx*betax)**0.5)
    plt.ylim()
    plt.gca().set_facecolor('#f1f1f1')
    plt.text(0.04, 0.80, xtextstr, transform=plt.gca().transAxes, fontsize=12, color='red', bbox=dict(facecolor='white', edgecolor='black', boxstyle='round,pad=0.3'))
    plt.grid()
    #draw_ellipse(alphax,betax,gammax,epsilonx)

    #alphay, betay, gammay, epsilony = get_CS_params(y,yp)
    #ytextstr = r'$\beta_y = %.2f m$'%(betay)+'\n'+r'$\alpha_y = %.2f$'%(alphay)+'\n'+r'$\epsilon_y (RMS) = %.2f$'%(epsilony*1E6)+r' $\pi*mm*mr$'
    #plt.subplot(122)
    #plt.title('Vertical')
    #plt.plot(y,yp,'o',markersize=markersize)
    #plt.xlabel('y [m]')
    #plt.ylabel('y\' [r]')
    #plt.xlim(-3.0*(epsilony*betay)**0.5, 3.0*(epsilony*betay)**0.5)
    #plt.ylim(-3.0*(epsilony*betay)**0.5, 3.0*(epsilony*betay)**0.5)
    #plt.gca().set_facecolor('#f1f1f1')
    #plt.text(0.50, 0.80, ytextstr, transform=plt.gca().transAxes, fontsize=12, color='red', bbox=dict(facecolor='white', edgecolor='black', boxstyle='round,pad=0.3'))
    #plt.grid()
    #draw_ellipse(alphay,betay,gammay,epsilony)
    #plt.tight_layout()
    
    

# Write the MADX input deck for the FODO lattice to get the matched CS params
write_FODO('FODO.madx')
run_MAD('FODO.madx')

# Read TWISS output and plot the results
names,keywords,s,betx,bety,alfx,alfy,mux,muy,dx,dy,L = parsetwiss('twiss.out')
fig5 = plot_twiss(names,keywords,s,betx,bety,dx,dy)
pdf.savefig(fig5)
# Read TWISS cell output and plot the results
cnames,ckeywords,cs,cbetx,cbety,calfx,calfy,cmux,cmuy,cdx,cdy,cL = parsetwiss('twisscell.out')
fig4 = plot_twiss(cnames,ckeywords,cs,cbetx,cbety,cdx,cdy)
pdf.savefig(fig4)

# Write a new FODO_PTC deck with vectors from the matched CS params from above
nparticles =7
#ex = 10.0E-6 # Physical (geometric, non-normalized emittance), units of [pi*m*r]
#ey = 10.0E-6 # Physical (geometric, non-normalized emittance), units of [pi*m*r]
#x, px = makeParticles(alfx[0],betx[0],ex,nparticles)
#y, py = makeParticles(alfy[0],bety[0],ey,nparticles) # note, don't forget conversionbetween px and yp

dpp = [1.0E-4]*nparticles
n_turns=18
# Parse the PTC output
x_PTC, px_PTC, y_PTC, py_PTC = parse_tracking_output('trackone',nparticles,n_turns)

# Plot phase space for each observation point
for i in range(n_turns):#lmao this is broken af
    fig = PSplot(x_PTC[i],px_PTC[i],y_PTC[i],py_PTC[i], 'Title')
    pdf.savefig(fig)
pdf.close()